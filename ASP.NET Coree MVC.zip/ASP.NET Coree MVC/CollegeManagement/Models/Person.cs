namespace CollegeManagement.Models;

public abstract class Person
{
    protected string NameValue;
    protected string SurnameValue;
    protected int AgeValue;

    protected Person(string name, string surname, int age)
    {
        NameValue = ValidateText(name, nameof(name));
        SurnameValue = ValidateText(surname, nameof(surname));
        Age = age;
    }

    public string Name
    {
        get => NameValue;
        set => NameValue = ValidateText(value, nameof(Name));
    }

    public string Surname
    {
        get => SurnameValue;
        set => SurnameValue = ValidateText(value, nameof(Surname));
    }

    public int Age
    {
        get => AgeValue;
        set
        {
            if (value is < 15 or > 70)
            {
                throw new ArgumentOutOfRangeException(nameof(value), "Возраст должен быть от 15 до 70 лет.");
            }

            AgeValue = value;
        }
    }

    protected string DisplayBasicInfo() => $"{Name} {Surname}, {Age} лет";

    protected internal string GetFullName() => $"{Name} {Surname}";

    private protected static int CalculateStatistics(IEnumerable<int> values) =>
        values.Any() ? (int)Math.Round(values.Average()) : 0;

    protected static string ValidateText(string value, string parameterName)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new ArgumentException("Поле не может быть пустым.", parameterName);
        }

        return value.Trim();
    }
}
