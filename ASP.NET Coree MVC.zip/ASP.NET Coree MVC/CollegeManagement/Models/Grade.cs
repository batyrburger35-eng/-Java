namespace CollegeManagement.Models;

public sealed record Grade(Guid Id, Guid StudentId, string StudentName, string Subject, int Value, DateOnly Date);

public sealed record AttendanceRecord(Guid StudentId, string StudentName, DateOnly Date, bool Present);

public sealed class GradeBook
{
    private readonly List<Grade> _grades = [];

    public IReadOnlyList<Grade> Grades => _grades.AsReadOnly();

    public bool Add(Student student, string subject, int value)
    {
        ArgumentNullException.ThrowIfNull(student);
        if (value is < 2 or > 5 || string.IsNullOrWhiteSpace(subject))
        {
            return false;
        }

        _grades.Add(new Grade(Guid.NewGuid(), student.StudentId, student.GetStudentInfo(), subject.Trim(), value, DateOnly.FromDateTime(DateTime.Today)));
        return true;
    }

    public bool Remove(Guid id) => _grades.RemoveAll(grade => grade.Id == id) > 0;
    public void RemoveForStudent(Guid studentId) => _grades.RemoveAll(grade => grade.StudentId == studentId);
}

public sealed class LoginViewModel
{
    [System.ComponentModel.DataAnnotations.Required]
    [System.ComponentModel.DataAnnotations.Display(Name = "Логин")]
    public string Login { get; set; } = "";

    [System.ComponentModel.DataAnnotations.Required]
    [System.ComponentModel.DataAnnotations.DataType(System.ComponentModel.DataAnnotations.DataType.Password)]
    [System.ComponentModel.DataAnnotations.Display(Name = "Пароль")]
    public string Password { get; set; } = "";

    public string? ReturnUrl { get; set; }
}

internal sealed class CollegeSettings
{
    public string CollegeName { get; private set; } = "Колледж";
    public string AcademicYear { get; private set; } = "2026–2027";

    internal void Update(string collegeName, string academicYear)
    {
        if (string.IsNullOrWhiteSpace(collegeName) || string.IsNullOrWhiteSpace(academicYear))
        {
            throw new ArgumentException("Название колледжа и учебный год обязательны.");
        }

        CollegeName = collegeName.Trim();
        AcademicYear = academicYear.Trim();
    }
}
