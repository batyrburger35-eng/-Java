namespace CollegeManagement.Models;

public class User : Person
{
    public User(string login, string role)
        : base(login, "Пользователь", 18)
    {
        LoginName = ValidateText(login, nameof(login));
        Role = ValidateText(role, nameof(role));
    }

    public string LoginName { get; }
    public string Role { get; }
    public string GetSafeInfo() => $"{LoginName} ({Role})";
}

public sealed class Admin(string login) : User(login, "Admin");
public sealed class TeacherUser(string login) : User(login, "Teacher");
public sealed class StudentUser(string login) : User(login, "Student");
