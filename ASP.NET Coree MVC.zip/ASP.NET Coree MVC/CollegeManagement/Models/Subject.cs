namespace CollegeManagement.Models;

public sealed class Subject
{
    private Teacher? _teacher;

    public Subject(string name, int hours)
    {
        Name = string.IsNullOrWhiteSpace(name) ? throw new ArgumentException("Укажите название предмета.", nameof(name)) : name.Trim();
        if (hours is < 1 or > 1000)
        {
            throw new ArgumentOutOfRangeException(nameof(hours), "Количество часов должно быть от 1 до 1000.");
        }

        Hours = hours;
    }

    public string Name { get; }
    public int Hours { get; }
    public Teacher? AssignedTeacher => _teacher;

    public void AssignTeacher(Teacher teacher) => _teacher = teacher ?? throw new ArgumentNullException(nameof(teacher));
}
