using CollegeManagement.Data;
using CollegeManagement.Models;

namespace CollegeManagement.Services;

public sealed class AttendanceManager
{
    private readonly object _lock = new();
    private readonly Dictionary<Guid, Dictionary<DateOnly, bool>> _attendance = [];
    private readonly CollegeDbContext _db;

    public AttendanceManager(CollegeDbContext db)
    {
        _db = db;
        var today = DateOnly.FromDateTime(DateTime.Today);
        foreach (var student in db.Students)
        {
            _attendance[student.StudentId] = new Dictionary<DateOnly, bool> { [today] = true };
        }
    }

    public bool SetAttendance(Guid studentId, DateOnly date, bool present)
    {
        if (_db.FindStudent(studentId) is null)
        {
            return false;
        }

        lock (_lock)
        {
            if (!_attendance.TryGetValue(studentId, out var dates))
            {
                dates = [];
                _attendance.Add(studentId, dates);
            }

            dates[date] = present;
        }

        return true;
    }

    public IReadOnlyList<AttendanceRecord> GetRecords()
    {
        lock (_lock)
        {
            return _attendance
                .SelectMany(student => student.Value.Select(day =>
                {
                    var person = _db.FindStudent(student.Key);
                    return person is null
                        ? null
                        : new AttendanceRecord(student.Key, person.GetStudentInfo(), day.Key, day.Value);
                }))
                .Where(record => record is not null)
                .Select(record => record!)
                .OrderByDescending(record => record.Date)
                .ThenBy(record => record.StudentName)
                .ToArray();
        }
    }

    public (int Total, int Present, int Absent) GetStatistics()
    {
        lock (_lock)
        {
            var all = _attendance.Values.SelectMany(days => days.Values).ToArray();
            return (all.Length, all.Count(present => present), all.Count(present => !present));
        }
    }
}
